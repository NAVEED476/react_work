export function Users(props) {
  return (
    <>
      <div>
        <h1>{props.Name}</h1>

        <h1>{(props.something, props.otherthings)}</h1>
      </div>
      <div>
        <h1>something</h1>
        <h2>Nothing</h2>
      </div>
    </>
  );
}
