import { useState } from "react";

export function Counter(){
      let [count,setcounter] = useState(1)

      const clickfun = () =>{
            
            setcounter(count+1)
      }
      const subfunction = () =>{
            setcounter(count-1)
      }

      const mul = ()=>{
            setcounter(count*2)
      }

      const clear = ()=>{
            setcounter(0)
      }
      
      return <div>
            <h1>count : {count}</h1>
            <button onClick={clickfun}>Addition</button>
            <button onClick={subfunction}>Subtraction</button>

            <button onClick={mul}>multiply by 2</button>

            <button onClick={clear}>Clear</button>
      </div>
}