
import './App.css';
import { Users } from './components/user';
import {Counter} from './components/component'


function App() {
  return <div className="App">
      <Users Name="naveed" something="is something" otherthings="some other things?"/>  
      <Counter/>
  </div>
  
}

export default App;
